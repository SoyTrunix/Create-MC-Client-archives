package net.minecraftforge.client.model;

import javax.vecmath.Matrix4f;
import org.apache.commons.lang3.NotImplementedException;

public class TRSRTransformation
{
    public TRSRTransformation(Matrix4f matrix)
    {
        throw new NotImplementedException("Forge dummy class");
    }
}
