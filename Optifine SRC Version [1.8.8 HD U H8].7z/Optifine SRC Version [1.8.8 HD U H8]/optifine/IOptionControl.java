package optifine;

import net.minecraft.client.settings.GameSettings;

public interface IOptionControl
{
    GameSettings.Options getOption();
}
