package optifine;

import java.lang.reflect.Field;

public interface IFieldLocator
{
    Field getField();
}
